package com.example.rooms.service;

import com.example.rooms.model.Room;
import com.example.rooms.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    private final RoomRepository repository;

    public RoomService(RoomRepository repository) {
        this.repository = repository;
    }

    public Room create(Room room) {
        return repository.save(room);
    }

    public List<Room> getAll() {
        return repository.findAll();
    }

    public Optional<Room> getById(String id) {
        return repository.findById(id);
    }

    public Room update(String id, Room updatedRoom) {
        Optional<Room> existingRoomOpt = repository.findById(id);

        if (existingRoomOpt.isPresent()) {
            Room room = existingRoomOpt.get();
            room.setRoomNumber(updatedRoom.getRoomNumber());
            room.setRoomType(updatedRoom.getRoomType());
            room.setNumberOfPax(updatedRoom.getNumberOfPax());
            room.setPricePerNight(updatedRoom.getPricePerNight());
            room.setAmenities(updatedRoom.getAmenities());
            return repository.save(room);
        } else {
            return null;
        }
    }

    public void delete(String id) {
        repository.deleteById(id);
    }
}