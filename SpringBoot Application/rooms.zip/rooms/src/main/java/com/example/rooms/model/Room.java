package com.example.rooms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "rooms")
public class Room {

    @Id
    private String id;
    private String roomNumber;
    private String roomType;
    private int numberOfPax;
    private double pricePerNight;
    private List<String> amenities;

    // Getters
    public String getId() {
        return id;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public int getNumberOfPax() {
        return numberOfPax;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public List<String> getAmenities() {
        return amenities;
    }

    // Setters
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setNumberOfPax(int numberOfPax) {
        this.numberOfPax = numberOfPax;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public void setAmenities(List<String> amenities) {
        this.amenities = amenities;
    }
}