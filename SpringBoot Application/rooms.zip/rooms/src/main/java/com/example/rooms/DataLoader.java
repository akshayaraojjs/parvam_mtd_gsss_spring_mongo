package com.example.rooms;

import com.example.rooms.model.Room;
import com.example.rooms.repository.RoomRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class DataLoader implements CommandLineRunner {

    private final RoomRepository roomRepository;

    public DataLoader(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public void run(String... args) {
        if (roomRepository.count() == 0) {
            Room room1 = new Room();
            room1.setRoomNumber("A101");
            room1.setRoomType("Family");
            room1.setNumberOfPax(3);
            room1.setPricePerNight(2500.0);
            room1.setAmenities(Arrays.asList("Wifi", "AC", "TV", "Parking"));

            Room room2 = new Room();
            room2.setRoomNumber("B202");
            room2.setRoomType("Double");
            room2.setNumberOfPax(2);
            room2.setPricePerNight(1800.0);
            room2.setAmenities(Arrays.asList("Wifi", "Fan"));

            roomRepository.saveAll(Arrays.asList(room1, room2));

            System.out.println("Sample rooms inserted.");
        } else {
            System.out.println("Rooms already exist in the database.");
        }
    }
}
